`check_practice_typing.exe` is a standalone Windows .exe for ease of launching.

Just download this .exe file, double-click and enjoy the typing program as you would
when running in an explicit Python environment.

This .exe was created with the Python external library [`PyInstaller`](https://pyinstaller.org/en).